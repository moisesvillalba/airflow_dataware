# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago
from datetime import timedelta
import pandas as pd
import sqlalchemy
from sqlalchemy.exc import SQLAlchemyError

# Parámetros de la base de datos
DB_CONNECTION_STRING = "postgresql+psycopg2://airflow:airflow@postgres:5432/airflow"
DIM_PRODUCTO_TABLE = "dimension_producto"
DIM_CLIENTE_TABLE = "dimension_cliente"
DIM_FECHA_TABLE = "dimension_fecha"
HECHOS_VENTAS_TABLE = "hechos_ventas"

def cargar_dimension_producto(**kwargs):
    """
    Carga datos en la tabla de dimensión Producto.
    """
    data = {
        "nombre_producto": ["Producto A", "Producto B", "Producto C"]
    }
    df = pd.DataFrame(data)
    engine = sqlalchemy.create_engine(DB_CONNECTION_STRING)
    try:
        df.to_sql(DIM_PRODUCTO_TABLE, con=engine, if_exists='replace', index=False)
        print("Datos de dimensión Producto cargados exitosamente.")
    except SQLAlchemyError as e:
        print(f"Error al cargar datos en dimension_producto: {e}")
        raise  # Propagar el error para que Airflow registre el fallo

def cargar_dimension_cliente(**kwargs):
    """
    Carga datos en la tabla de dimensión Cliente.
    """
    data = {
        "nombre_cliente": ["Cliente X", "Cliente Y", "Cliente Z"]
    }
    df = pd.DataFrame(data)
    engine = sqlalchemy.create_engine(DB_CONNECTION_STRING)
    try:
        df.to_sql(DIM_CLIENTE_TABLE, con=engine, if_exists='replace', index=False)
        print("Datos de dimensión Cliente cargados exitosamente.")
    except SQLAlchemyError as e:
        print(f"Error al cargar datos en dimension_cliente: {e}")
        raise  # Propagar el error para que Airflow registre el fallo

def cargar_dimension_fecha(**kwargs):
    """
    Carga datos en la tabla de dimensión Fecha.
    """
    data = {
        "fecha": ["2024-07-01", "2024-07-02", "2024-07-03"],
        "mes": [7, 7, 7],
        "año": [2024, 2024, 2024]
    }
    df = pd.DataFrame(data)
    engine = sqlalchemy.create_engine(DB_CONNECTION_STRING)
    try:
        df.to_sql(DIM_FECHA_TABLE, con=engine, if_exists='replace', index=False)
        print("Datos de dimensión Fecha cargados exitosamente.")
    except SQLAlchemyError as e:
        print(f"Error al cargar datos en dimension_fecha: {e}")
        raise  # Propagar el error para que Airflow registre el fallo

def cargar_hechos_ventas(**kwargs):
    """
    Carga datos en la tabla de Hechos Ventas.
    """
    data = {
        "id_producto": [1, 2, 3],
        "id_cliente": [1, 2, 3],
        "id_fecha": [1, 2, 3],
        "cantidad": [10, 20, 15],
        "total": [100.00, 200.00, 150.00]
    }
    df = pd.DataFrame(data)
    engine = sqlalchemy.create_engine(DB_CONNECTION_STRING)
    try:
        df.to_sql(HECHOS_VENTAS_TABLE, con=engine, if_exists='replace', index=False)
        print("Datos de Hechos Ventas cargados exitosamente.")
    except SQLAlchemyError as e:
        print(f"Error al cargar datos en hechos_ventas: {e}")
        raise  # Propagar el error para que Airflow registre el fallo

default_args = {
    'owner': 'airflow',
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='cargar_data_warehouse_dag',
    default_args=default_args,
    description='DAG para cargar datos en un Data Warehouse básico',
    schedule_interval='@daily',
    start_date=days_ago(1),
    catchup=False,
) as dag:
    
    start = DummyOperator(task_id='start')

    cargar_producto = PythonOperator(
        task_id='cargar_dimension_producto',
        python_callable=cargar_dimension_producto,
        provide_context=True
    )

    cargar_cliente = PythonOperator(
        task_id='cargar_dimension_cliente',
        python_callable=cargar_dimension_cliente,
        provide_context=True
    )

    cargar_fecha = PythonOperator(
        task_id='cargar_dimension_fecha',
        python_callable=cargar_dimension_fecha,
        provide_context=True
    )

    cargar_hechos = PythonOperator(
        task_id='cargar_hechos_ventas',
        python_callable=cargar_hechos_ventas,
        provide_context=True
    )

    end = DummyOperator(task_id='end')

    start >> [cargar_producto, cargar_cliente, cargar_fecha] >> cargar_hechos >> end